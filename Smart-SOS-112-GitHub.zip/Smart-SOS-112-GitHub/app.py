"""Smart SOS 112 backend implemented with Python's standard library only.

Local prototype only. This application never places an emergency call by itself.
"""
from __future__ import annotations

import csv
import hashlib
import hmac
import io
import json
import mimetypes
import os
import secrets
import sqlite3
import time
from datetime import datetime, timezone
from contextlib import closing
from http import HTTPStatus
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import parse_qs
from wsgiref.simple_server import make_server, WSGIServer
from socketserver import ThreadingMixIn
from typing import Any

BASE_DIR = Path(__file__).resolve().parent
# Read a simple .env file without requiring python-dotenv.
_env_file = BASE_DIR / ".env"
if _env_file.exists():
    for _line in _env_file.read_text(encoding="utf-8").splitlines():
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _key, _value = _line.split("=", 1)
            os.environ.setdefault(_key.strip(), _value.strip().strip('"').strip("'"))
DB_PATH = Path(os.environ.get("DATABASE_PATH", BASE_DIR / "smart_sos.db"))
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "demo1234")
SECRET_KEY = os.environ.get("SECRET_KEY", "local-demo-secret-change-before-deployment")
DEVICE_API_KEY = os.environ.get("DEVICE_API_KEY", "demo-device-key-change-me")
DEVICE_ID = os.environ.get("DEVICE_ID", "esp32-001")
DEVICE_NAME = os.environ.get("DEVICE_NAME", "ESP32 Wearable")
MAX_BODY = 1_000_000


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect_db() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    with closing(connect_db()) as db, db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS devices (
                id TEXT PRIMARY KEY, name TEXT NOT NULL, last_seen TEXT,
                latitude REAL, longitude REAL, firmware_version TEXT,
                sensor_data TEXT NOT NULL DEFAULT '{}'
            );
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT, event_key TEXT UNIQUE,
                device_id TEXT NOT NULL, event_type TEXT NOT NULL, severity TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'active', summary TEXT NOT NULL,
                sensor_data TEXT NOT NULL DEFAULT '{}', latitude REAL, longitude REAL,
                created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                FOREIGN KEY(device_id) REFERENCES devices(id)
            );
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT, alert_id INTEGER,
                action TEXT NOT NULL, details TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
                FOREIGN KEY(alert_id) REFERENCES alerts(id)
            );
            CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        db.execute("INSERT OR IGNORE INTO devices(id,name) VALUES(?,?)", (DEVICE_ID, DEVICE_NAME))
        for key, value in {"impact_threshold_g": "3.0", "motionless_seconds": "15", "health_alert_mode": "review"}.items():
            db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (key, value))


def issue_session() -> str:
    stamp = str(int(time.time()))
    nonce = secrets.token_urlsafe(24)
    payload = f"{stamp}.{nonce}"
    signature = hmac.new(SECRET_KEY.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return f"{payload}.{signature}"


def valid_session(cookie_header: str) -> bool:
    cookie = SimpleCookie()
    try:
        cookie.load(cookie_header or "")
        token = cookie.get("sos_session").value if cookie.get("sos_session") else ""
        stamp, nonce, signature = token.split(".", 2)
        payload = f"{stamp}.{nonce}"
        expected = hmac.new(SECRET_KEY.encode(), payload.encode(), hashlib.sha256).hexdigest()
        return (secrets.compare_digest(signature, expected)
                and 0 <= int(time.time()) - int(stamp) <= 43200)
    except (ValueError, TypeError, AttributeError):
        return False


def read_body(environ: dict[str, Any]) -> bytes:
    try:
        length = int(environ.get("CONTENT_LENGTH") or 0)
    except ValueError:
        raise ValueError("Invalid Content-Length")
    if length < 0 or length > MAX_BODY:
        raise ValueError("Request body too large")
    return environ["wsgi.input"].read(length) if length else b""


def parse_json(raw: bytes) -> dict[str, Any]:
    try:
        data = json.loads(raw.decode("utf-8") or "{}")
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ValueError("Invalid JSON body")
    if not isinstance(data, dict):
        raise ValueError("Expected a JSON object")
    return data


def finite_number(value: Any, name: str, minimum: float, maximum: float) -> float | None:
    if value is None or value == "":
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{name} must be numeric")
    if not (minimum <= number <= maximum):
        raise ValueError(f"{name} must be between {minimum} and {maximum}")
    return number


def json_object(value: Any) -> str:
    if not isinstance(value, dict):
        raise ValueError("sensor_data must be a JSON object")
    return json.dumps(value, separators=(",", ":"))


def log_action(db: sqlite3.Connection, alert_id: int | None, action: str, details: str = "") -> None:
    db.execute("INSERT INTO audit_log(alert_id,action,details,created_at) VALUES(?,?,?,?)", (alert_id, action, details[:500], now_iso()))


def get_settings(db: sqlite3.Connection) -> dict[str, Any]:
    values = {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings")}
    return {"impact_threshold_g": float(values.get("impact_threshold_g", 3.0)),
            "motionless_seconds": int(values.get("motionless_seconds", 15)),
            "health_alert_mode": values.get("health_alert_mode", "review")}


def row_to_alert(row: sqlite3.Row) -> dict[str, Any]:
    item = dict(row)
    try:
        item["sensor_data"] = json.loads(item.get("sensor_data") or "{}")
    except json.JSONDecodeError:
        item["sensor_data"] = {}
    return item


def create_alert(db: sqlite3.Connection, payload: dict[str, Any], source: str) -> tuple[int, bool]:
    event_type = str(payload.get("event_type", "other")).lower()
    if event_type not in {"fall", "health", "manual_sos", "impact", "other"}:
        raise ValueError("Unsupported event_type")
    severity = str(payload.get("severity", "high")).lower()
    if severity not in {"critical", "high", "medium", "low"}:
        raise ValueError("Unsupported severity")
    device_id = str(payload.get("device_id", DEVICE_ID))[:80]
    if not db.execute("SELECT id FROM devices WHERE id=?", (device_id,)).fetchone():
        db.execute("INSERT INTO devices(id,name) VALUES(?,?)", (device_id, device_id))
    latitude = finite_number(payload.get("latitude"), "latitude", -90, 90)
    longitude = finite_number(payload.get("longitude"), "longitude", -180, 180)
    sensor_data = json_object(payload.get("sensor_data", {}))
    event_key = str(payload.get("event_key") or "")[:120] or None
    if event_key:
        existing = db.execute("SELECT id FROM alerts WHERE event_key=?", (event_key,)).fetchone()
        if existing:
            return int(existing["id"]), False
    summary_map = {"fall": "Possible fall detected", "health": "Possible health alert reported by device",
                   "manual_sos": "Manual SOS button activated", "impact": "High impact detected", "other": "Device reported an event"}
    summary = str(payload.get("summary") or summary_map[event_type])[:200]
    timestamp = now_iso()
    cursor = db.execute("""INSERT INTO alerts(event_key,device_id,event_type,severity,status,summary,sensor_data,
        latitude,longitude,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
        (event_key, device_id, event_type, severity, "active", summary, sensor_data, latitude, longitude, timestamp, timestamp))
    alert_id = int(cursor.lastrowid)
    log_action(db, alert_id, "created", f"Source: {source}")
    return alert_id, True


def json_response(start_response, status: int, data: dict[str, Any], headers: list[tuple[str, str]] | None = None):
    body = json.dumps(data, separators=(",", ":")).encode("utf-8")
    response_headers = [("Content-Type", "application/json; charset=utf-8"), ("Content-Length", str(len(body))), ("Cache-Control", "no-store")]
    if headers:
        response_headers.extend(headers)
    start_response(f"{status} {HTTPStatus(status).phrase}", response_headers)
    return [body]


def html_response(start_response, body: bytes, status: int = 200, headers: list[tuple[str, str]] | None = None):
    response_headers = [("Content-Type", "text/html; charset=utf-8"), ("Content-Length", str(len(body))), ("Cache-Control", "no-store")]
    if headers:
        response_headers.extend(headers)
    start_response(f"{status} {HTTPStatus(status).phrase}", response_headers)
    return [body]


def redirect(start_response, location: str, cookie: str | None = None):
    headers = [("Location", location), ("Content-Length", "0"), ("Cache-Control", "no-store")]
    if cookie:
        headers.append(("Set-Cookie", cookie))
    start_response("303 See Other", headers)
    return [b""]


def app(environ, start_response):
    method = environ.get("REQUEST_METHOD", "GET").upper()
    path = environ.get("PATH_INFO", "/")
    query = parse_qs(environ.get("QUERY_STRING", ""))
    logged_in = valid_session(environ.get("HTTP_COOKIE", ""))

    # Static files are served from a fixed directory; path traversal is rejected.
    if method == "GET" and path.startswith("/static/"):
        rel = path.removeprefix("/static/")
        target = (BASE_DIR / "static" / rel).resolve()
        static_root = (BASE_DIR / "static").resolve()
        if static_root not in target.parents or not target.is_file():
            return json_response(start_response, 404, {"error": "Not found"})
        content = target.read_bytes()
        mime = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        start_response("200 OK", [("Content-Type", mime), ("Content-Length", str(len(content))), ("Cache-Control", "public, max-age=300")])
        return [content]

    if path == "/login" and method == "GET":
        body = (BASE_DIR / "templates" / "login.html").read_bytes()
        return html_response(start_response, body)
    if path == "/login" and method == "POST":
        raw = read_body(environ).decode("utf-8", "replace")
        form = parse_qs(raw)
        password = form.get("password", [""])[0]
        if secrets.compare_digest(password, ADMIN_PASSWORD):
            session_cookie = f"sos_session={issue_session()}; Path=/; Max-Age=43200; HttpOnly; SameSite=Lax"
            return redirect(start_response, "/", session_cookie)
        return redirect(start_response, "/login?error=1")
    if path == "/logout" and method == "POST":
        if not logged_in:
            return redirect(start_response, "/login")
        return redirect(start_response, "/login", "sos_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax")
    if path == "/" and method == "GET":
        if not logged_in:
            return redirect(start_response, "/login")
        page = (BASE_DIR / "templates" / "index.html").read_text(encoding="utf-8")
        page = page.replace("__DEVICE_ID_JSON__", json.dumps(DEVICE_ID)).replace("__DEVICE_NAME_JSON__", json.dumps(DEVICE_NAME))
        return html_response(start_response, page.encode("utf-8"))

    # All non-device APIs require an authenticated operator session.
    is_device_route = path.startswith("/api/device/")
    if path.startswith("/api/") and path != "/api/health" and not is_device_route and not logged_in:
        return json_response(start_response, 401, {"error": "Login required"})

    try:
        if path == "/api/health" and method == "GET":
            return json_response(start_response, 200, {"ok": True, "service": "Smart SOS 112", "timestamp": now_iso()})

        if path.startswith("/api/device/"):
            supplied = environ.get("HTTP_X_DEVICE_KEY", "")
            if not secrets.compare_digest(supplied, DEVICE_API_KEY):
                return json_response(start_response, 401, {"error": "Unauthorized device"})
            payload = parse_json(read_body(environ)) if method == "POST" else {}
            with closing(connect_db()) as db, db:
                if path == "/api/device/alert" and method == "POST":
                    payload.setdefault("device_id", DEVICE_ID)
                    alert_id, created = create_alert(db, payload, "ESP32 device")
                    db.execute("UPDATE devices SET last_seen=? WHERE id=?", (now_iso(), str(payload["device_id"])))
                    return json_response(start_response, 201 if created else 200, {"ok": True, "alert_id": alert_id, "created": created})
                if path == "/api/device/heartbeat" and method == "POST":
                    device_id = str(payload.get("device_id") or DEVICE_ID)[:80]
                    lat = finite_number(payload.get("latitude"), "latitude", -90, 90)
                    lon = finite_number(payload.get("longitude"), "longitude", -180, 180)
                    sensor_data = json_object(payload.get("sensor_data", {}))
                    firmware = str(payload.get("firmware_version") or "unknown")[:40]
                    db.execute("""INSERT INTO devices(id,name,last_seen,latitude,longitude,firmware_version,sensor_data)
                        VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,last_seen=excluded.last_seen,
                        latitude=excluded.latitude,longitude=excluded.longitude,firmware_version=excluded.firmware_version,
                        sensor_data=excluded.sensor_data""",
                        (device_id, str(payload.get("device_name") or device_id)[:100], now_iso(), lat, lon, firmware, sensor_data))
                    return json_response(start_response, 200, {"ok": True, "device_id": device_id, "received_at": now_iso()})
                if path == "/api/device/config" and method == "GET":
                    return json_response(start_response, 200, {"settings": get_settings(db), "device_id": DEVICE_ID})
            return json_response(start_response, 404, {"error": "Not found"})

        if path == "/api/dashboard" and method == "GET":
            with closing(connect_db()) as db, db:
                devices = [dict(r) for r in db.execute("SELECT * FROM devices ORDER BY name")]
                current = datetime.now(timezone.utc)
                for device in devices:
                    try:
                        seen = datetime.fromisoformat(device["last_seen"]) if device["last_seen"] else None
                        if seen and seen.tzinfo is None:
                            seen = seen.replace(tzinfo=timezone.utc)
                        device["online"] = bool(seen and (current-seen).total_seconds() <= 90)
                    except ValueError:
                        device["online"] = False
                    device["sensor_data"] = json.loads(device.get("sensor_data") or "{}")
                alerts = [row_to_alert(r) for r in db.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 50")]
                active = db.execute("SELECT COUNT(*) FROM alerts WHERE status IN ('active','acknowledged')").fetchone()[0]
                total = db.execute("SELECT COUNT(*) FROM alerts").fetchone()[0]
                return json_response(start_response, 200, {"alerts": alerts, "devices": devices, "active_alerts": active,
                    "total_alerts": total, "settings": get_settings(db), "server_time": now_iso()})

        if path == "/api/demo/trigger" and method == "POST":
            payload = parse_json(read_body(environ))
            payload.setdefault("device_id", DEVICE_ID)
            payload.setdefault("severity", "high")
            if payload.get("event_type") not in {"fall", "health", "manual_sos", "impact"}:
                return json_response(start_response, 400, {"error": "Unsupported demo event"})
            with closing(connect_db()) as db, db:
                alert_id, created = create_alert(db, payload, "Dashboard simulation")
                return json_response(start_response, 201 if created else 200, {"ok": True, "alert_id": alert_id, "created": created})

        if path == "/api/settings" and method == "POST":
            payload = parse_json(read_body(environ))
            impact = finite_number(payload.get("impact_threshold_g"), "impact_threshold_g", 1.5, 8.0)
            motionless = finite_number(payload.get("motionless_seconds"), "motionless_seconds", 5, 60)
            mode = payload.get("health_alert_mode", "review")
            if impact is None or motionless is None:
                return json_response(start_response, 400, {"error": "Both thresholds are required"})
            if mode not in {"review", "alert"}:
                return json_response(start_response, 400, {"error": "Invalid health_alert_mode"})
            with closing(connect_db()) as db, db:
                for key, value in {"impact_threshold_g": str(round(impact, 1)), "motionless_seconds": str(int(motionless)), "health_alert_mode": mode}.items():
                    db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
                return json_response(start_response, 200, {"ok": True, "settings": get_settings(db)})

        if path.startswith("/api/alerts/") and method == "GET":
            try:
                alert_id = int(path.split("/")[3])
            except (ValueError, IndexError):
                return json_response(start_response, 404, {"error": "Alert not found"})
            with closing(connect_db()) as db, db:
                row = db.execute("SELECT * FROM alerts WHERE id=?", (alert_id,)).fetchone()
                if row is None:
                    return json_response(start_response, 404, {"error": "Alert not found"})
                audit = [dict(r) for r in db.execute("SELECT action,details,created_at FROM audit_log WHERE alert_id=? ORDER BY id", (alert_id,))]
                return json_response(start_response, 200, {"alert": row_to_alert(row), "audit": audit})

        if path.startswith("/api/alerts/") and method == "POST":
            parts = path.strip("/").split("/")
            if len(parts) != 4:
                return json_response(start_response, 404, {"error": "Not found"})
            try:
                alert_id = int(parts[2])
            except ValueError:
                return json_response(start_response, 404, {"error": "Alert not found"})
            action_to_status = {"acknowledge": "acknowledged", "resolve": "resolved", "cancel": "cancelled"}
            status = action_to_status.get(parts[3])
            if not status:
                return json_response(start_response, 404, {"error": "Not found"})
            with closing(connect_db()) as db, db:
                row = db.execute("SELECT status FROM alerts WHERE id=?", (alert_id,)).fetchone()
                if row is None:
                    return json_response(start_response, 404, {"error": "Alert not found"})
                if row["status"] in {"resolved", "cancelled"}:
                    return json_response(start_response, 409, {"error": "Closed incidents cannot be changed"})
                db.execute("UPDATE alerts SET status=?,updated_at=? WHERE id=?", (status, now_iso(), alert_id))
                log_action(db, alert_id, status, "Dashboard operator")
                return json_response(start_response, 200, {"ok": True, "alert_id": alert_id, "status": status})

        if path == "/api/export.csv" and method == "GET":
            with closing(connect_db()) as db, db:
                rows = db.execute("SELECT id,device_id,event_type,severity,status,summary,latitude,longitude,created_at,updated_at FROM alerts ORDER BY id DESC").fetchall()
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerow(["id", "device_id", "event_type", "severity", "status", "summary", "latitude", "longitude", "created_at", "updated_at"])
            writer.writerows([tuple(r) for r in rows])
            data = output.getvalue().encode("utf-8")
            start_response("200 OK", [("Content-Type", "text/csv; charset=utf-8"), ("Content-Length", str(len(data))), ("Content-Disposition", "attachment; filename=smart_sos_alerts.csv")])
            return [data]

    except ValueError as exc:
        return json_response(start_response, 400, {"error": str(exc)})
    except sqlite3.Error as exc:
        return json_response(start_response, 500, {"error": "Database operation failed", "detail": str(exc)})
    except Exception:
        return json_response(start_response, 500, {"error": "Internal server error"})

    return json_response(start_response, 404, {"error": "Not found"})


class ThreadingWSGIServer(ThreadingMixIn, WSGIServer):
    daemon_threads = True


init_db()

if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "5000"))
    print(f"Smart SOS 112 dashboard running at http://{host}:{port}")
    print("Local prototype only. It will not automatically call 112.")
    with make_server(host, port, app, server_class=ThreadingWSGIServer) as server:
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped.")
