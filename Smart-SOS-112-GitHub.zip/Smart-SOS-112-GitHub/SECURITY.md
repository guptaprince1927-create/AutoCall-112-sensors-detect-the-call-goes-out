# Security notes

This repository is an educational prototype. Do not expose its development server directly to the public internet or use it to provide life-safety services.

If you discover a security issue, do not post credentials, personal data, or exploitable details in a public issue. Contact the repository maintainer privately through the contact method listed in the GitHub repository profile.

Before any deployment, add HTTPS, secure secret management, device credential rotation, rate limiting, hardened authentication/session handling, audit and backup controls, and an independently reviewed deployment architecture.
