/*
  Smart SOS 112 - ESP32 + MPU6050 + optional NEO-6M GPS
  Sends sensor heartbeats and possible-fall alerts to the Python dashboard backend.

  IMPORTANT SAFETY LIMITS:
  - This firmware does NOT dial 112 or send SMS to emergency services.
  - It reports sensor events to your private dashboard only.
  - Validate the fall-detection algorithm using safe, controlled tests.
  - For remote use, use HTTPS with a properly validated server certificate.
*/
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <TinyGPSPlus.h>
#include <MAX30105.h>
#include "heartRate.h"

// -------- CONFIGURE THESE VALUES --------
const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
// For local testing, use your computer's LAN IP, not 127.0.0.1.
const char* API_BASE_URL = "http://192.168.1.100:5000";
const char* DEVICE_API_KEY = "demo-device-key-change-me";
const char* DEVICE_ID = "esp32-001";
const char* FIRMWARE_VERSION = "0.1.0";
// ----------------------------------------

const int SOS_BUTTON_PIN = 25;          // Button wired between GPIO25 and GND
const int GPS_RX_PIN = 16;              // ESP32 RX2 <- GPS TX
const int GPS_TX_PIN = 17;              // ESP32 TX2 -> GPS RX (optional)
const unsigned long HEARTBEAT_INTERVAL_MS = 20000;
const unsigned long SENSOR_INTERVAL_MS = 100;
const float DEFAULT_IMPACT_THRESHOLD_G = 3.0;
const unsigned long DEFAULT_MOTIONLESS_MS = 15000;
const float STILL_GYRO_THRESHOLD = 0.25; // radians/sec; tune with real measurements

Adafruit_MPU6050 mpu;
TinyGPSPlus gps;
MAX30105 pulseSensor;
HardwareSerial gpsSerial(2);
float impactThresholdG = DEFAULT_IMPACT_THRESHOLD_G;
unsigned long motionlessMs = DEFAULT_MOTIONLESS_MS;
unsigned long lastHeartbeat = 0;
unsigned long lastSample = 0;
unsigned long stillSince = 0;
unsigned long candidateSince = 0;
bool impactCandidate = false;
bool lastButtonState = HIGH;
bool mpuReady = false;
bool pulseReady = false;
float currentBpm = 0.0f;
float averageBpm = 0.0f;
long lastBeatAt = 0;
unsigned long abnormalHrSince = 0;
unsigned long lastHealthAlertAt = 0;
long latestIrValue = 0;

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi");
  unsigned long started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < 20000) {
    delay(400);
    Serial.print('.');
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("Wi-Fi connected. ESP32 IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("Wi-Fi not connected yet; will retry in loop.");
  }
}

bool postJson(const String& path, JsonDocument& doc) {
  if (WiFi.status() != WL_CONNECTED) return false;
  WiFiClient client;
  HTTPClient http;
  String url = String(API_BASE_URL) + path;
  if (!http.begin(client, url)) return false;
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", DEVICE_API_KEY);
  String body;
  serializeJson(doc, body);
  int status = http.POST(body);
  String response = http.getString();
  Serial.printf("POST %s -> %d %s\n", path.c_str(), status, response.c_str());
  http.end();
  return status >= 200 && status < 300;
}

void getServerSettings() {
  if (WiFi.status() != WL_CONNECTED) return;
  WiFiClient client;
  HTTPClient http;
  String url = String(API_BASE_URL) + "/api/device/config";
  if (!http.begin(client, url)) return;
  http.addHeader("X-Device-Key", DEVICE_API_KEY);
  int status = http.GET();
  if (status == 200) {
    JsonDocument doc;
    if (deserializeJson(doc, http.getString()) == DeserializationError::Ok) {
      impactThresholdG = doc["settings"]["impact_threshold_g"] | DEFAULT_IMPACT_THRESHOLD_G;
      motionlessMs = (doc["settings"]["motionless_seconds"] | 15UL) * 1000UL;
      Serial.printf("Loaded thresholds: %.1f g, %lu ms\n", impactThresholdG, motionlessMs);
    }
  } else {
    Serial.printf("Could not load settings: HTTP %d\n", status);
  }
  http.end();
}

void addGps(JsonDocument& doc) {
  if (gps.location.isValid() && gps.location.age() < 10000) {
    doc["latitude"] = gps.location.lat();
    doc["longitude"] = gps.location.lng();
  }
}

void sendHeartbeat(float accelerationG, float gyroMagnitude) {
  JsonDocument doc;
  doc["device_id"] = DEVICE_ID;
  doc["device_name"] = "ESP32 Wearable";
  doc["firmware_version"] = FIRMWARE_VERSION;
  JsonObject sensors = doc["sensor_data"].to<JsonObject>();
  sensors["acceleration_g"] = accelerationG;
  sensors["gyro_rad_s"] = gyroMagnitude;
  sensors["mpu6050"] = mpuReady ? "ready" : "not_ready";
  sensors["max30102"] = pulseReady ? "ready" : "not_ready";
  if (pulseReady && millis() - lastBeatAt < 5000 && currentBpm > 0) {
    sensors["heart_rate_bpm"] = averageBpm;
  }
  addGps(doc);
  postJson("/api/device/heartbeat", doc);
}

void sendFallAlert(float accelerationG, float gyroMagnitude) {
  JsonDocument doc;
  doc["event_key"] = String(DEVICE_ID) + "-fall-" + String(millis());
  doc["device_id"] = DEVICE_ID;
  doc["event_type"] = "fall";
  doc["severity"] = "high";
  doc["summary"] = "Possible fall detected by ESP32 sensor";
  JsonObject sensors = doc["sensor_data"].to<JsonObject>();
  sensors["impact_g"] = accelerationG;
  sensors["gyro_rad_s"] = gyroMagnitude;
  sensors["motionless_confirmation_ms"] = motionlessMs;
  addGps(doc);
  bool ok = postJson("/api/device/alert", doc);
  Serial.println(ok ? "Fall event delivered to dashboard." : "Fall event delivery failed.");
}

void sendManualSOS() {
  JsonDocument doc;
  doc["event_key"] = String(DEVICE_ID) + "-sos-" + String(millis());
  doc["device_id"] = DEVICE_ID;
  doc["event_type"] = "manual_sos";
  doc["severity"] = "critical";
  doc["summary"] = "Manual SOS button activated on device";
  JsonObject sensors = doc["sensor_data"].to<JsonObject>();
  sensors["source"] = "physical SOS button";
  addGps(doc);
  postJson("/api/device/alert", doc);
}


void sendHealthAlert(float bpm) {
  JsonDocument doc;
  doc["event_key"] = String(DEVICE_ID) + "-health-" + String(millis());
  doc["device_id"] = DEVICE_ID;
  doc["event_type"] = "health";
  doc["severity"] = "medium";
  doc["summary"] = "Persistent unusual pulse-rate reading; operator review needed";
  JsonObject sensors = doc["sensor_data"].to<JsonObject>();
  sensors["heart_rate_bpm"] = bpm;
  sensors["source"] = "MAX30102 optical pulse sensor";
  sensors["measurement_status"] = "prototype estimate; not a diagnosis";
  addGps(doc);
  postJson("/api/device/alert", doc);
}

void updatePulseSensor() {
  if (!pulseReady) return;
  pulseSensor.check();
  while (pulseSensor.available()) {
    latestIrValue = pulseSensor.getIR();
    if (latestIrValue > 50000 && checkForBeat(latestIrValue)) {
      long now = millis();
      long delta = now - lastBeatAt;
      lastBeatAt = now;
      if (delta > 0) {
        float measured = 60000.0f / (float)delta;
        if (measured >= 30.0f && measured <= 220.0f) {
          currentBpm = measured;
          averageBpm = averageBpm == 0 ? measured : (0.75f * averageBpm + 0.25f * measured);
        }
      }
    }
    pulseSensor.nextSample();
  }

  // Illustrative prototype thresholds only. They are not medical limits or a diagnosis.
  // Require persistent readings and impose a cooldown to reduce repeated alerts.
  bool recentReading = lastBeatAt > 0 && millis() - lastBeatAt < 5000;
  bool fingerPresent = latestIrValue > 50000;
  bool unusual = recentReading && fingerPresent && (averageBpm < 40.0f || averageBpm > 150.0f);
  if (unusual) {
    if (abnormalHrSince == 0) abnormalHrSince = millis();
    if (millis() - abnormalHrSince >= 30000 && millis() - lastHealthAlertAt >= 600000) {
      sendHealthAlert(averageBpm);
      lastHealthAlertAt = millis();
      abnormalHrSince = 0;
    }
  } else {
    abnormalHrSince = 0;
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(SOS_BUTTON_PIN, INPUT_PULLUP);
  Wire.begin();
  gpsSerial.begin(9600, SERIAL_8N1, GPS_RX_PIN, GPS_TX_PIN);

  pulseReady = pulseSensor.begin(Wire, I2C_SPEED_FAST);
  if (pulseReady) {
    // SparkFun MAX3010x library setup. Place a finger gently over the sensor.
    pulseSensor.setup(0x1F, 4, 2, 100, 411, 4096);
    pulseSensor.setPulseAmplitudeRed(0x0A);
    pulseSensor.setPulseAmplitudeGreen(0);
    Serial.println("MAX30102 pulse sensor ready.");
  } else {
    Serial.println("MAX30102 not found. Pulse alerts are disabled.");
  }

  mpuReady = mpu.begin();
  if (mpuReady) {
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
    Serial.println("MPU6050 ready.");
  } else {
    Serial.println("ERROR: MPU6050 not found. Check wiring.");
  }

  connectWiFi();
  getServerSettings();
  lastHeartbeat = millis();
}

void loop() {
  while (gpsSerial.available()) gps.encode(gpsSerial.read());
  updatePulseSensor();

  if (WiFi.status() != WL_CONNECTED) {
    static unsigned long lastReconnect = 0;
    if (millis() - lastReconnect > 10000) {
      lastReconnect = millis();
      WiFi.reconnect();
    }
  }

  // Debounced physical SOS button (active LOW).
  bool buttonState = digitalRead(SOS_BUTTON_PIN);
  static unsigned long buttonChangedAt = 0;
  if (buttonState != lastButtonState) {
    lastButtonState = buttonState;
    buttonChangedAt = millis();
  }
  if (buttonState == LOW && millis() - buttonChangedAt > 60) {
    sendManualSOS();
    while (digitalRead(SOS_BUTTON_PIN) == LOW) delay(20); // one event per press
    delay(100);
  }

  if (!mpuReady || millis() - lastSample < SENSOR_INTERVAL_MS) {
    delay(5);
    return;
  }
  lastSample = millis();

  sensors_event_t accel, gyro, temp;
  mpu.getEvent(&accel, &gyro, &temp);
  float x = accel.acceleration.x;
  float y = accel.acceleration.y;
  float z = accel.acceleration.z;
  float accelMagnitude = sqrt(x*x + y*y + z*z);
  float accelerationG = accelMagnitude / 9.80665f;
  float gyroMagnitude = sqrt(gyro.gyro.x*gyro.gyro.x + gyro.gyro.y*gyro.gyro.y + gyro.gyro.z*gyro.gyro.z);

  if (!impactCandidate && accelerationG >= impactThresholdG) {
    impactCandidate = true;
    stillSince = 0;
    candidateSince = millis();
    Serial.println("High impact candidate. Checking follow-up movement...");
  }

  if (impactCandidate) {
    bool nearOneG = accelerationG >= 0.80f && accelerationG <= 1.20f;
    bool lowRotation = gyroMagnitude <= STILL_GYRO_THRESHOLD;
    if (nearOneG && lowRotation) {
      if (stillSince == 0) stillSince = millis();
      if (millis() - stillSince >= motionlessMs) {
        sendFallAlert(accelerationG, gyroMagnitude);
        impactCandidate = false;
        stillSince = 0;
        candidateSince = 0;
      }
    } else {
      stillSince = 0;
      // Cancel a candidate after 60 seconds; do not leave it armed forever.
      if (candidateSince == 0) candidateSince = millis();
      if (millis() - candidateSince > 60000) {
        impactCandidate = false;
        candidateSince = 0;
        Serial.println("Impact candidate expired without confirmation.");
      }
    }
  }

  if (millis() - lastHeartbeat >= HEARTBEAT_INTERVAL_MS) {
    lastHeartbeat = millis();
    sendHeartbeat(accelerationG, gyroMagnitude);
  }
}
