# ESP32 firmware notes

The main sketch is `esp32_smart_sos.ino`.

Before compiling, install these Arduino libraries:

1. Adafruit MPU6050
2. Adafruit Unified Sensor
3. ArduinoJson 7
4. TinyGPSPlus
5. SparkFun MAX3010x Sensor Library

The `heartRate.h` helper is distributed with the SparkFun library's heart-rate example on some library releases. Open the library's `Example5_HeartRate` (or similarly named Heart Rate example) and copy its `heartRate.h` file into the same Arduino sketch folder as `esp32_smart_sos.ino`. The MAX30105 driver header comes from the installed library.

The sketch is a reference integration, not a medical or certified fall-detection algorithm. Board pinouts, sensor breakout voltage, I2C addresses, and library versions can vary. Verify wiring and compile against your exact board and installed library versions before connecting any wearable hardware.

The sketch currently reports an approximate pulse-rate signal from the MAX30102. It does not calculate SpO2. It uses illustrative abnormal pulse bands only to create a dashboard event for human review. It never calls 112.
