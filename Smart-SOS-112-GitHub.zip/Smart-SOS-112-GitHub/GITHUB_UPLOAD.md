# Upload this project to GitHub

## Option 1 — GitHub website (no command line)

1. Extract `Smart-SOS-112-GitHub.zip` on your computer.
2. Sign in to GitHub and create a **New repository**.
3. Give it a name such as `smart-sos-112`. Choose Public or Private as appropriate.
4. Open the new, empty repository and select **Add file → Upload files**.
5. Open the extracted `Smart-SOS-112-GitHub` folder on your computer and drag its **contents** into the GitHub upload area. Include hidden items such as `.gitignore` and the `.github` folder if your file picker allows them.
6. Enter a commit message such as `Initial Smart SOS 112 project` and choose **Commit changes**.

**Important:** Do not upload the ZIP file as a single repository file. Extract it first, then upload the files and folders inside it.

## Option 2 — Git command line

Open a terminal in the extracted `Smart-SOS-112-GitHub` folder and run:

```bash
git init
git add .
git commit -m "Initial Smart SOS 112 project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with the URL of your own GitHub repository.

## Before publishing

- Never commit your real `.env` file, passwords, API keys, database files, or Wi-Fi credentials.
- `.gitignore` excludes `.env`, the local SQLite database, Python bytecode, and virtual environments.
- Keep `.env.example` as a template; enter real secrets only in your local `.env` file.
- Review the README safety notes. This is a prototype, not a certified life-safety product, and it does not automatically call 112.
