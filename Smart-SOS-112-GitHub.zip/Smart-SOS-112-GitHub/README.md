# Smart SOS 112 — Working Web Prototype

A local incident-management website and ESP32-to-server API for a BCA hardware/software project. It includes a Python standard-library HTTP backend, SQLite storage, a responsive dashboard, incident acknowledgement/resolution, audit trail, settings, CSV export, browser notifications, GPS display links, simulated events, and an ESP32 firmware sketch.

> **Safety boundary:** This software does not automatically call 112. The dashboard only provides a deliberate, human-confirmed `tel:112` action. The ESP32 firmware sends data to the dashboard; it does not dial emergency services. Do not test calls to emergency services. Treat this as a prototype, not a certified life-safety product.

## 1. Run the website locally

Requirements: Python 3.10 or newer. No third-party Python packages are needed.

### Windows (PowerShell)

```powershell
cd smart_sos_112
py -m venv .venv
.venv\Scripts\Activate.ps1
$env:ADMIN_PASSWORD = "choose-a-strong-password"
$env:SECRET_KEY = "replace-with-a-long-random-secret"
$env:DEVICE_API_KEY = "replace-with-a-long-random-device-key"
py app.py
```

### macOS / Linux

```bash
cd smart_sos_112
python3 -m venv .venv
source .venv/bin/activate
export ADMIN_PASSWORD='choose-a-strong-password'
export SECRET_KEY='replace-with-a-long-random-secret'
export DEVICE_API_KEY='replace-with-a-long-random-device-key'
python app.py
```

Open **http://127.0.0.1:5000**. If you did not set `ADMIN_PASSWORD`, the local-demo password is `demo1234`. Change it before any use beyond a private local demo. The default device key is `demo-device-key-change-me`; replace it in both the server environment and the ESP32 sketch.

The database `smart_sos.db` is created automatically beside `app.py`.

## 2. Dashboard functions

- Live dashboard refreshes every 3 seconds.
- Simulate fall, health, and manual-SOS incidents (simulation only).
- Review and filter incident status.
- Acknowledge, resolve, or classify an active item as a false alarm.
- GPS coordinates received from the device appear as map links.
- Device online status is based on a heartbeat received within 90 seconds.
- Save impact and motionless thresholds to SQLite; the ESP32 reads them from `/api/device/config`.
- Optional browser notifications (permission is requested only after the operator clicks Notifications).
- Export incidents to CSV.
- Manual 112 dialer link requires an extra confirmation checkbox and a separate click. It is not triggered by sensor events.

## 3. ESP32 hardware integration

Example parts:

- ESP32 development board
- MPU6050 accelerometer/gyroscope
- MAX30102 optical pulse sensor (pulse-rate estimate only; optional but needed for the demo health-alert heuristic)
- Optional NEO-6M GPS
- Momentary SOS switch
- Stable, protected battery power supply

The example sketch is in `firmware/esp32_smart_sos.ino`.

Arduino IDE libraries:

- Adafruit MPU6050
- Adafruit Unified Sensor
- ArduinoJson (v7 compatible)
- TinyGPSPlus
- SparkFun MAX3010x Sensor Library (provides `MAX30105.h` and the `heartRate.h` example helper)

### Example wiring

| Module | Module pin | ESP32 pin |
|---|---|---|
| MPU6050 / MAX30102 | SDA | GPIO 21 |
| MPU6050 / MAX30102 | SCL | GPIO 22 |
| MPU6050 | VCC/GND | Match module voltage; GND to GND |
| NEO-6M (optional) | TX | GPIO 16 (ESP32 RX2) |
| NEO-6M (optional) | RX | GPIO 17 (ESP32 TX2) |
| SOS pushbutton | One side | GPIO 25 |
| SOS pushbutton | Other side | GND |

Check the exact breakout board voltage requirements before wiring. Do not connect a 5V signal to an ESP32 GPIO.

### Configure the sketch

1. Set Wi-Fi name and password.
2. Set `API_BASE_URL` to the computer's LAN IP, for example `http://192.168.1.20:5000` (not `127.0.0.1`).
3. Set `DEVICE_API_KEY` to exactly match the server's `DEVICE_API_KEY` environment variable.
4. Set device ID consistently, e.g. `esp32-001`.
5. Flash the sketch and inspect Serial Monitor at 115200 baud.
6. Keep laptop and ESP32 on a trusted private network. The server default host is localhost; to test from ESP32, start it with `HOST=0.0.0.0` on your private LAN, and configure firewall rules. Do not expose this development server directly to the public internet.

For example, on macOS/Linux: `HOST=0.0.0.0 python app.py`. In PowerShell: `$env:HOST='0.0.0.0'; py app.py`.

The firmware sends:

- `POST /api/device/heartbeat` every 20 seconds with device status, pulse-rate estimate, motion sensor values, and optional GPS.
- `POST /api/device/alert` after an impact and post-impact stillness heuristic, or when the physical SOS button is pressed.
- `GET /api/device/config` to read the dashboard's thresholds.

All device endpoints require the `X-Device-Key` HTTP header.

## 4. API contract

### Device heartbeat

```http
POST /api/device/heartbeat
X-Device-Key: YOUR_DEVICE_KEY
Content-Type: application/json
```

```json
{
  "device_id": "esp32-001",
  "device_name": "ESP32 Wearable",
  "firmware_version": "0.1.0",
  "latitude": 28.6139,
  "longitude": 77.2090,
  "sensor_data": {"acceleration_g": 1.0, "gyro_rad_s": 0.02}
}
```

### Device alert

```http
POST /api/device/alert
X-Device-Key: YOUR_DEVICE_KEY
Content-Type: application/json
```

```json
{
  "event_key": "esp32-001-event-000123",
  "device_id": "esp32-001",
  "event_type": "fall",
  "severity": "high",
  "summary": "Possible fall detected by ESP32 sensor",
  "latitude": 28.6139,
  "longitude": 77.2090,
  "sensor_data": {"impact_g": 3.4, "gyro_rad_s": 0.04}
}
```

Allowed event types: `fall`, `health`, `manual_sos`, `impact`, `other`. Allowed severities: `critical`, `high`, `medium`, `low`. `event_key` provides idempotency so retries do not create duplicate incidents.

### Protected dashboard API

- `GET /api/dashboard`
- `GET /api/alerts/<id>`
- `POST /api/alerts/<id>/acknowledge`
- `POST /api/alerts/<id>/resolve`
- `POST /api/alerts/<id>/cancel`
- `POST /api/demo/trigger`
- `POST /api/settings`
- `GET /api/export.csv`

## 5. Verify the server without hardware

With the server running and signed into the dashboard, use the three test buttons. A test incident should appear, increment the open incident count, and offer Acknowledge / Resolve / False alarm actions. These tests are entirely local and never dial 112.

You can also verify the device endpoint with curl:

```bash
curl -X POST http://127.0.0.1:5000/api/device/heartbeat \
  -H 'Content-Type: application/json' \
  -H 'X-Device-Key: YOUR_DEVICE_KEY' \
  -d '{"device_id":"esp32-001","firmware_version":"0.1.0","sensor_data":{"acceleration_g":1.0}}'
```

## 6. Before any real-world deployment

This prototype is not a substitute for a certified medical or personal safety device. A single accelerometer threshold can mistake ordinary movement for a fall or miss a real fall. Calibrate using diverse, safe, supervised scenarios and evaluate false-positive and false-negative rates. The MAX30102 example estimates pulse rate only; it does not calculate SpO₂. Its illustrative alert bands (below 40 or above 150 BPM sustained for 30 seconds) are not medical thresholds, are not diagnoses, can be wrong, and are not suitable for medical decisions. Health readings from consumer optical sensors are affected by motion, placement, perfusion, and skin contact.

A public deployment needs, at minimum: HTTPS with certificate validation, unique per-device credentials and rotation, role-based operator accounts, rate limiting, encrypted secrets, backups, server monitoring, tamper-resistant device enclosures, battery-failure alerts, offline buffering/retry, privacy and consent controls, independent validation, and a documented emergency-services integration approved by the relevant authorities. Emergency calls should be integrated only through a verified and authorized pathway and never be triggered by demo data.

## 7. Publish this project on GitHub

See [GITHUB_UPLOAD.md](GITHUB_UPLOAD.md) for step-by-step instructions for uploading the extracted project through GitHub's website or using Git. A GitHub Actions workflow in `.github/workflows/tests.yml` runs the unit tests on pushes and pull requests.
