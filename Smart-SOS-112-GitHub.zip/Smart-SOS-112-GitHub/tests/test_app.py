import io
import json
import os
import tempfile
import unittest
from urllib.parse import urlencode
from wsgiref.util import setup_testing_defaults

TEST_DIR = tempfile.TemporaryDirectory()
os.environ["DATABASE_PATH"] = os.path.join(TEST_DIR.name, "test.db")
os.environ["ADMIN_PASSWORD"] = "test-password"
os.environ["SECRET_KEY"] = "test-secret-key"
os.environ["DEVICE_API_KEY"] = "test-device-key"

import app as smart_app  # noqa: E402


def call(path, method="GET", payload=None, cookie="", headers=None, form=None):
    env = {}
    setup_testing_defaults(env)
    body = json.dumps(payload).encode() if payload is not None else (urlencode(form).encode() if form is not None else b"")
    env.update({"REQUEST_METHOD": method, "PATH_INFO": path, "QUERY_STRING": "",
                "CONTENT_LENGTH": str(len(body)), "wsgi.input": io.BytesIO(body),
                "HTTP_COOKIE": cookie, "CONTENT_TYPE": "application/json" if payload is not None else "application/x-www-form-urlencoded"})
    for key, value in (headers or {}).items():
        env["HTTP_" + key.upper().replace("-", "_")] = value
    captured = {}
    def start_response(status, response_headers):
        captured["status"] = int(status.split()[0])
        captured["headers"] = dict(response_headers)
    response = b"".join(smart_app.app(env, start_response))
    captured["body"] = response
    return captured


class SmartSOSApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        result = call("/login", "POST", form={"password": "test-password"})
        cls.cookie = result["headers"]["Set-Cookie"].split(";", 1)[0]

    def test_dashboard_requires_login(self):
        result = call("/api/dashboard")
        self.assertEqual(result["status"], 401)

    def test_demo_alert_and_lifecycle(self):
        result = call("/api/demo/trigger", "POST", {"event_type": "fall", "summary": "TEST fall"}, self.cookie)
        self.assertEqual(result["status"], 201)
        alert_id = json.loads(result["body"])["alert_id"]
        ack = call(f"/api/alerts/{alert_id}/acknowledge", "POST", {}, self.cookie)
        self.assertEqual(ack["status"], 200)
        resolved = call(f"/api/alerts/{alert_id}/resolve", "POST", {}, self.cookie)
        self.assertEqual(resolved["status"], 200)
        dashboard = json.loads(call("/api/dashboard", cookie=self.cookie)["body"])
        self.assertEqual(dashboard["active_alerts"], 0)
        self.assertGreaterEqual(dashboard["total_alerts"], 1)

    def test_device_auth_and_idempotency(self):
        payload = {"event_key": "unit-test-001", "device_id": "esp32-001", "event_type": "fall", "severity": "high", "sensor_data": {"impact_g": 3.2}}
        denied = call("/api/device/alert", "POST", payload)
        self.assertEqual(denied["status"], 401)
        headers = {"X-Device-Key": "test-device-key"}
        first = call("/api/device/alert", "POST", payload, headers=headers)
        second = call("/api/device/alert", "POST", payload, headers=headers)
        self.assertEqual(first["status"], 201)
        self.assertEqual(second["status"], 200)
        self.assertEqual(json.loads(first["body"])["alert_id"], json.loads(second["body"])["alert_id"])

    def test_heartbeat_and_settings(self):
        headers = {"X-Device-Key": "test-device-key"}
        heartbeat = call("/api/device/heartbeat", "POST", {"device_id":"esp32-001", "latitude":28.6, "longitude":77.2, "sensor_data":{"acceleration_g":1.0}}, headers=headers)
        self.assertEqual(heartbeat["status"], 200)
        settings = call("/api/settings", "POST", {"impact_threshold_g":3.5, "motionless_seconds":20, "health_alert_mode":"review"}, self.cookie)
        self.assertEqual(settings["status"], 200)
        self.assertEqual(json.loads(settings["body"])["settings"]["impact_threshold_g"], 3.5)


if __name__ == "__main__":
    unittest.main()
