(() => {
  const $ = (id) => document.getElementById(id);
  let lastAlertId = 0;
  let firstLoad = true;
  let currentAlerts = [];
  let refreshBusy = false;

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function timeAgo(value) {
    if (!value) return 'Never connected';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    const seconds = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    return `${Math.floor(seconds / 3600)}h ago`;
  }
  function niceStatus(status) { return ({active:'Active', acknowledged:'Acknowledged', resolved:'Resolved', cancelled:'Cancelled'})[status] || status; }
  function toast(message, type='success') {
    const node = document.createElement('div');
    node.className = `toast ${type === 'error' ? 'error' : ''}`;
    node.textContent = message;
    $('toastStack').append(node);
    setTimeout(() => node.remove(), 4000);
  }
  async function api(url, options={}) {
    const response = await fetch(url, {credentials:'same-origin', headers:{'Content-Type':'application/json', ...(options.headers || {})}, ...options});
    let data = {};
    try { data = await response.json(); } catch (_) { data = {}; }
    if (response.status === 401) { window.location.href = '/login'; throw new Error('Please sign in again.'); }
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
    return data;
  }
  function alertMarkup(a) {
    const icon = ({fall:'↘', health:'♡', manual_sos:'✚', impact:'⚡'})[a.event_type] || '!';
    const detail = a.latitude != null && a.longitude != null
      ? `<a target="_blank" rel="noopener" href="https://www.openstreetmap.org/?mlat=${encodeURIComponent(a.latitude)}&mlon=${encodeURIComponent(a.longitude)}#map=17/${encodeURIComponent(a.latitude)}/${encodeURIComponent(a.longitude)}">View GPS ↗</a>`
      : 'GPS unavailable';
    const sensorValues = Object.entries(a.sensor_data || {}).slice(0,4).map(([k,v]) => `${escapeHtml(k)}: ${escapeHtml(v)}`).join(' · ');
    let buttons = '';
    if (a.status === 'active') buttons += `<button class="btn btn-outline" data-action="ack" data-id="${a.id}">Acknowledge</button>`;
    if (a.status === 'active' || a.status === 'acknowledged') buttons += `<button class="btn btn-primary" data-action="resolve" data-id="${a.id}">Resolve</button>`;
    if (a.status === 'active') buttons += `<button class="btn btn-quiet" data-action="cancel" data-id="${a.id}">False alarm</button>`;
    return `<article class="alert-card ${a.severity === 'critical' ? 'critical' : ''} ${a.event_type}">
      <div class="alert-symbol">${icon}</div><div class="alert-main"><div class="alert-title-row"><span class="alert-title">${escapeHtml(a.summary)}</span><span class="severity ${escapeHtml(a.severity)}">${escapeHtml(a.severity)}</span></div>
      <div class="alert-meta"><span>#${a.id}</span><span>${escapeHtml(a.device_id)}</span><span>${escapeHtml(timeAgo(a.created_at))}</span><span>${detail}</span></div>
      ${sensorValues ? `<div class="alert-summary">${sensorValues}</div>` : `<div class="alert-summary">${escapeHtml(a.event_type.replace('_',' '))} event · ${escapeHtml(a.device_id)}</div>`}</div>
      <div class="alert-actions"><span class="status-chip ${escapeHtml(a.status)}">${niceStatus(a.status)}</span><div class="action-row">${buttons}</div></div></article>`;
  }
  function renderAlerts(alerts) {
    currentAlerts = alerts;
    const filter = $('statusFilter').value;
    const shown = filter === 'all' ? alerts : alerts.filter(a => a.status === filter);
    $('alertsList').innerHTML = shown.length ? shown.map(alertMarkup).join('') : `<div class="empty-state"><div class="empty-symbol">✓</div><strong>No matching incidents</strong><p>Try another status filter or simulate an event.</p></div>`;
  }
  function renderDevices(devices) {
    $('deviceCount').textContent = devices.length;
    const online = devices.filter(d => d.online).length;
    $('onlineCount').textContent = `${online} online · ${devices.length-online} offline`;
    $('deviceList').innerHTML = devices.length ? devices.map(d => {
      const sensor = d.sensor_data || {};
      const metrics = [];
      if (sensor.heart_rate_bpm != null) metrics.push(`Pulse ${Number(sensor.heart_rate_bpm).toFixed(0)} bpm`);
      if (sensor.acceleration_g != null) metrics.push(`Motion ${Number(sensor.acceleration_g).toFixed(2)} g`);
      if (sensor.max30102) metrics.push(`Pulse sensor ${escapeHtml(sensor.max30102)}`);
      if (sensor.mpu6050) metrics.push(`IMU ${escapeHtml(sensor.mpu6050)}`);
      return `<div class="device-row"><div class="device-avatar">⌁</div><div class="device-info"><strong>${escapeHtml(d.name)}</strong><small>${escapeHtml(d.id)} · ${d.online ? 'Seen ' + timeAgo(d.last_seen) : 'Offline'}</small>${d.firmware_version ? `<small>Firmware ${escapeHtml(d.firmware_version)}</small>` : ''}${metrics.length ? `<small>${metrics.join(' · ')}</small>` : ''}</div><span class="online-dot ${d.online?'':'offline'}" title="${d.online?'Online':'Offline'}"></span></div>`;
    }).join('') : '<p class="muted small">No registered devices.</p>';
    $('systemStatus').textContent = online ? 'Online' : 'Waiting';
    $('systemStatus').style.color = online ? 'var(--green)' : 'var(--amber)';
    $('systemStatusSub').textContent = online ? `${online} device heartbeat received` : 'No recent device heartbeat';
    const withGps = [...devices].reverse().find(d => d.latitude != null && d.longitude != null);
    $('locationDetails').innerHTML = withGps ? `Device: ${escapeHtml(withGps.name)}<br>Lat: ${Number(withGps.latitude).toFixed(6)} · Lon: ${Number(withGps.longitude).toFixed(6)}<br><a target="_blank" rel="noopener" href="https://www.openstreetmap.org/?mlat=${withGps.latitude}&mlon=${withGps.longitude}#map=16/${withGps.latitude}/${withGps.longitude}">Open location map ↗</a>` : 'No coordinates received yet';
  }
  function renderActivity(alerts) {
    const entries = [];
    alerts.slice(0,7).forEach(a => {
      entries.push({title:`${a.summary}`, detail:`Incident #${a.id} · ${niceStatus(a.status)}`, time:a.updated_at || a.created_at});
    });
    $('activityList').innerHTML = entries.length ? entries.map(e => `<div class="activity-item"><div class="activity-mark">•</div><div class="activity-copy">${escapeHtml(e.title)}<small>${escapeHtml(e.detail)} · ${escapeHtml(timeAgo(e.time))}</small></div></div>`).join('') : '<p class="muted small">No activity recorded yet.</p>';
  }
  function updateSettings(settings) {
    $('impactThreshold').value = settings.impact_threshold_g;
    $('impactOutput').textContent = `${Number(settings.impact_threshold_g).toFixed(1)} g`;
    $('motionlessSeconds').value = settings.motionless_seconds;
    $('motionlessOutput').textContent = `${settings.motionless_seconds} sec`;
    $('healthMode').value = settings.health_alert_mode;
  }
  async function refresh() {
    if (refreshBusy) return;
    refreshBusy = true;
    try {
      const data = await api('/api/dashboard');
      $('connectionText').textContent = 'Dashboard connected';
      document.querySelector('.connection').classList.add('ok');
      document.querySelector('.connection').classList.remove('bad');
      $('lastUpdated').textContent = `Updated ${new Date().toLocaleTimeString()}`;
      $('activeCount').textContent = data.active_alerts;
      $('totalCount').textContent = data.total_alerts;
      renderDevices(data.devices);
      renderAlerts(data.alerts);
      renderActivity(data.alerts);
      if (firstLoad) updateSettings(data.settings);
      const newest = data.alerts.reduce((max,a) => Math.max(max,a.id), 0);
      if (!firstLoad && newest > lastAlertId) {
        const fresh = data.alerts.filter(a => a.id > lastAlertId);
        fresh.forEach(a => {
          toast(`New alert: ${a.summary}`, 'error');
          if ('Notification' in window && Notification.permission === 'granted') new Notification('Smart SOS 112 alert', {body:a.summary});
        });
      }
      lastAlertId = Math.max(lastAlertId, newest);
      firstLoad = false;
    } catch (err) {
      $('connectionText').textContent = 'Connection issue';
      document.querySelector('.connection').classList.add('bad');
      document.querySelector('.connection').classList.remove('ok');
      if (!firstLoad) console.warn(err);
    } finally { refreshBusy = false; }
  }
  async function demo(type) {
    const summaries = {fall:'SIMULATION: Possible fall detected',health:'SIMULATION: Health sensor alert for operator review',manual_sos:'SIMULATION: Manual SOS activated'};
    try {
      await api('/api/demo/trigger', {method:'POST', body:JSON.stringify({event_type:type, severity:type==='manual_sos'?'critical':'high', summary:summaries[type], sensor_data:{source:'dashboard demo', simulated:true}})});
      toast('Demo incident created. No call was placed.');
      await refresh();
    } catch (e) { toast(e.message,'error'); }
  }
  async function updateAlert(id, action) {
    const labels = {ack:'acknowledge',resolve:'resolve',cancel:'cancel'};
    try {
      await api(`/api/alerts/${id}/${labels[action]}`, {method:'POST',body:'{}'});
      toast(action === 'cancel' ? 'Incident marked as a false alarm.' : `Incident ${action === 'ack' ? 'acknowledged' : 'resolved'}.`);
      await refresh();
    } catch (e) { toast(e.message,'error'); }
  }
  $('alertsList').addEventListener('click', e => {
    const button = e.target.closest('button[data-action]');
    if (button) updateAlert(button.dataset.id, button.dataset.action);
  });
  document.querySelectorAll('[data-demo]').forEach(button => button.addEventListener('click', () => demo(button.dataset.demo)));
  $('statusFilter').addEventListener('change', () => renderAlerts(currentAlerts));
  $('impactThreshold').addEventListener('input', e => $('impactOutput').textContent = `${Number(e.target.value).toFixed(1)} g`);
  $('motionlessSeconds').addEventListener('input', e => $('motionlessOutput').textContent = `${e.target.value} sec`);
  $('settingsForm').addEventListener('submit', async e => {
    e.preventDefault();
    try {
      const settings = await api('/api/settings', {method:'POST', body:JSON.stringify({impact_threshold_g:Number($('impactThreshold').value),motionless_seconds:Number($('motionlessSeconds').value),health_alert_mode:$('healthMode').value})});
      updateSettings(settings.settings);
      $('settingsMessage').textContent = 'Settings saved.';
      toast('Detection settings saved.');
    } catch (err) { $('settingsMessage').textContent = err.message; toast(err.message,'error'); }
  });
  $('notifyBtn').addEventListener('click', async () => {
    if (!('Notification' in window)) return toast('Browser notifications are not supported here.','error');
    const permission = await Notification.requestPermission();
    toast(permission === 'granted' ? 'Browser notifications enabled.' : 'Notification permission not granted.', permission === 'granted' ? 'success' : 'error');
  });
  const modal = $('callModal');
  function closeModal(){modal.hidden=true;$('callConfirm').checked=false;$('dial112').classList.add('disabled');$('dial112').setAttribute('aria-disabled','true');}
  $('openCallBtn').addEventListener('click', () => { modal.hidden = false; });
  $('closeCall').addEventListener('click', closeModal);
  $('cancelCall').addEventListener('click', closeModal);
  modal.addEventListener('click', e => {if(e.target===modal)closeModal();});
  $('callConfirm').addEventListener('change', e => {$('dial112').classList.toggle('disabled',!e.target.checked);$('dial112').setAttribute('aria-disabled',String(!e.target.checked));});
  $('dial112').addEventListener('click', e => {if(!$('callConfirm').checked){e.preventDefault();return;} closeModal();});
  // Manual call only: a user opens the confirmation dialog, checks the genuine-emergency box, and taps the dialer link.
  window.openEmergencyCallDialog = () => { modal.hidden = false; };
  refresh();
  setInterval(refresh, 3000);
})();
